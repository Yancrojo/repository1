surtimax=[{"product": "jabon", "price": 1200, "available": 15}, 
          {"product": "azucar", "price": 1500, "available": 25},
          {"product": "arroz", "price": 3000, "available": 20},
          {"product": "aceite", "price": 3500, "available": 30},
          {"product": "clorox", "price": 13000, "available": 2800}]
#------------------//---------------------------------------------------------------
#Add product to inventory 
for i in range (5):
    new_product=str(input(f"Ingrese nuevo producto: {i+1} "))
    price= float(input(" Ingrese precio del producto: "))
    available= int(input (" Ingrese cantidad disponible: "))
    disp={" product":new_product, "price":price, "available":available}
    surtimax.append(disp)
print(surtimax)
#---------------------//------------------------------------------------------------
#Search for product in inventory 
def Search_for_product():
            product=input( " Buscar producto: ")
            for value in surtimax:
                    print(value)
                    print(product)
                    if value["product"]== product:
                            break
                    print(" El producto no esta en el inventario: ")
            else:   
                print(" Ingresa una opción válida")

#--------------------------//-------------------------------------------------------------
#option to search for existing product in inventory and change sales price
def Search_for_prodcut_to_update():
                    product=input(" Producto para cambiar precio: ")
                    for value  in surtimax:
                        print(value)
                        print(product)
                        if value["product"] == product:
                            break
                        print( "Error, Ingresa texto")    
                           
#----------------------//--------------------------------------------------------------
#Update Price 
def update_price(): 
    for i, value in surtimax:
        try: 
            valor=input("ingrese el nombre del producto actulizado")
            newprice=input(" Ingrese precio actualizado" )
            if value ["product"]== valor:
                surtimax[i].update({"price": newprice})
                print(surtimax)
            else: 
                print("Error, Ingrese nuevo precio")
            break
        except ValueError:
            print("Intenta de nuevo")

#---------------------//----------------------------------------------------------------
#Remove product 
def remove_product():
    i=0 
    product=input("Producto que desea eliminar del inventario: " )
    for producto in (surtimax):
        i=i+1
        if producto ["product"]==product:
            i=i-1
            del surtimax[i]
            break
        else: 
            continue
        print(surtimax)

answer= """Selecciona una opción: 
        1. MOSTRAR INVENTARIO
        2. BUSCAR PRODUCTO
        3. ELEGIR PRODUCTO PARA CAMBIAR PRECIO
        4. CAMBIAR PRECIO
        5. ELIMINAR PRODUCTO
        6. SUMA TOTAL DE PRECIOS DE LA TIENDA 
        7. ABANDONAR 
"""
while True:
    number_option= input(answer)
    if number_option== "1":
        print(surtimax)
    elif number_option=="2":
       Search_for_product()
    elif number_option=="3":
        Search_for_prodcut_to_update()
    elif number_option=="4":
        update_price()
    elif number_option=="5":
        remove_product()
    elif number_option=="6":
        prices= lambda surtimax: sum(producto["price"]*producto["disponibles"] for producto in surtimax)
        Tprices= prices(surtimax)
        print( Tprices )
    elif number_option=="7":
        print("OFF")
        break
    else:
        print("Error, Ingresa un número de 1 a 7:")